//
//  File.swift
//  on the map 5.0
//
//  Created by hardik aghera on 13/11/16.
//  Copyright © 2016 hardik aghera. All rights reserved.
//

import Foundation

func performUIUpdatesOnMain(updates: @escaping () -> Void) {
    DispatchQueue.main.async() {
        updates()
    }
}
