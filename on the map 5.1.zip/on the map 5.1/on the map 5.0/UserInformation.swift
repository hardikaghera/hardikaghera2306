//
//  File.swift
//  on the map 5.0
//
//  Created by hardik aghera on 13/11/16.
//  Copyright © 2016 hardik aghera. All rights reserved.
//

import Foundation

// MARK: User information

struct UserInformation {
    static var firstName = ""
    static var lastName = ""
    static var latitude = 0.00
    static var longitude = 0.00
    static var mapString = ""
    static var mediaURL = ""
    static var objectId = ""
    static var userKey = ""
}
