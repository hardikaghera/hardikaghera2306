//
//  SecondViewController.swift
//  CoolTransistionAnimation
//
//  Created by Hardik Aghera on 19/04/18.
//  Copyright © 2018 Hardik Aghera. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    
    @IBOutlet weak var backgroundImage: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var goButton: UIButton!
    @IBOutlet weak var findLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()

        backgroundImage.alpha = 0
        titleLabel.alpha = 0
        descriptionLabel.alpha = 0
        goButton.alpha = 0
        findLabel.alpha = 0
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        UIView.animate(withDuration: 1, animations: { 
            self.backgroundImage.alpha = 0.3
        }) { (true) in
            UIView.animate(withDuration: 1, animations: { 
                self.titleLabel.alpha = 1
            }, completion: { (true) in
                UIView.animate(withDuration: 1, animations: { 
                    self.descriptionLabel.alpha = 1
                }, completion: { (true) in
                    UIView.animate(withDuration: 1, animations: { 
                        self.goButton.alpha = 1
                        self.findLabel.alpha = 1
                    })
                })
            })
        }
    }

    }
