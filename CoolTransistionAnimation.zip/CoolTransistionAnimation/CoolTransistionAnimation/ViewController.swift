//
//  ViewController.swift
//  CoolTransistionAnimation
//
//  Created by Hardik Aghera on 19/04/18.
//  Copyright © 2018 Hardik Aghera. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var transitionImage: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        animateBackground()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func animateBackground() {
        UIView.animate(withDuration: 15, delay: 0, options: [.autoreverse,.curveLinear,.repeat], animations: {
            let x = -(self.transitionImage.frame.width-self.view.frame.width)
            self.transitionImage.transform = CGAffineTransform(translationX: x, y: 0)
        })
    }

    
}

