//
//  ThirdViewController.swift
//  CoolTransistionAnimation
//
//  Created by Hardik Aghera on 20/04/18.
//  Copyright © 2018 Hardik Aghera. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    @IBOutlet weak var slideUpButton: UIButton!
    @IBOutlet weak var slideUpView: UIView!
    @IBOutlet weak var menuView: UIView!
    @IBOutlet weak var buttonStackView: UIStackView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        slideUpView.layer.cornerRadius = 22
    }
    
    @IBAction func slideUpButtonTapped(_ sender: Any) {
        if slideUpView.transform == CGAffineTransform.identity {
     //   self.buttonStackView.backgroundColor = UIColor.white
    UIView.animate(withDuration: 1, animations: {
        self.slideUpView.transform = CGAffineTransform(scaleX: 11, y: 11)
        self.menuView.transform = CGAffineTransform(translationX: 0, y: -67)
        self.slideUpButton.transform = CGAffineTransform(rotationAngle: self.radians(degrees: 180))
    }) { (true) in
        
        }
        }else {
          //  self.menuView.backgroundColor = UIColor.clear
            UIView.animate(withDuration: 1, animations: {
                self.slideUpView.transform = .identity
                self.menuView.transform = .identity
                self.slideUpButton.transform = .identity
            }) { (true) in
                
            }
        }
        
    }
    

    func radians(degrees: Double) -> CGFloat {
        return CGFloat(degrees * .pi / 180)
    }

}
