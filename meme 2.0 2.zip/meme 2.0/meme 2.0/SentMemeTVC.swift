//
//  SentMemeTVC.swift
//  MemeMe
//
//  Created by David Moeller on 26/08/16.
//  Copyright © 2016 David Moeller. All rights reserved.
//

import UIKit

class SentMemeTVC: UITableViewController {
	
	var memes : [Meme] {
		if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
			return appDelegate.memes
		} else {
			return [Meme]()
		}
	}

	@IBAction func doRefresh(_ sender: AnyObject) {
		tableView.reloadData()
		sender.endRefreshing()
	}
	
	override func viewWillAppear(_ animated: Bool) {
		tableView.contentInset = UIEdgeInsetsMake(65, 0, 50, 0)
		tableView.reloadData()
	}
	
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return memes.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
		guard let cell = tableView.dequeueReusableCell(withIdentifier: "memeTVCell", for: indexPath) as? MemeTVCell else {
			// Will fail -> Fail fast ;)
			return UITableViewCell()
		}
		
		cell.initialize(withMeme: memes[(indexPath as NSIndexPath).row])

        return cell
    }

    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }

    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
			guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
				return
			}
			appDelegate.memes.remove(at: (indexPath as NSIndexPath).row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
	
	override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
		performSegue(withIdentifier: "showMeme", sender: indexPath)
	}
	
	override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
		guard let indexPath = sender as? IndexPath else {
			return
		}
		
		guard let vc = segue.destination as? MemeDetailVC else {
			return
		}
		
		vc.memeImage = memes[(indexPath as NSIndexPath).row].memeImage
		
	}

}
