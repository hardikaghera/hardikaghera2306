//
//  SentMemeCVC.swift
//  MemeMe
//
//  Created by David Moeller on 26/08/16.
//  Copyright © 2016 David Moeller. All rights reserved.
//

import UIKit

private let reuseIdentifier = "memeCVCell"

class SentMemeCVC: UICollectionViewController {
	
	var memes : [Meme] {
		if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
			return appDelegate.memes
		} else {
			return [Meme]()
		}
	}
	
	@IBOutlet weak var flowLayout: UICollectionViewFlowLayout!
	
	override func viewWillAppear(_ animated: Bool) {
		collectionView?.contentInset = UIEdgeInsetsMake(65, 0, 50, 0)
		collectionView?.reloadData()
		
		// Configure Collection View Flow Layout
		let space: CGFloat = 3.0
		let dimension = (view.frame.size.width - (2 * space)) / 3.0
		
		flowLayout.minimumInteritemSpacing = space
		flowLayout.minimumLineSpacing = space
		flowLayout.itemSize = CGSize(width: dimension, height: dimension)
		
	}

    // MARK: UICollectionViewDataSource

    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }


    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return memes.count
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
		
		guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as? MemeCVCell else {
			// Will fail -> Fail fast ;)
			return UICollectionViewCell()
		}
    
		cell.initialize(withMeme: memes[(indexPath as NSIndexPath).row])
    
        return cell
    }
	
	override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
		performSegue(withIdentifier: "showMeme", sender: indexPath)
	}
	
	override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
		guard let indexPath = sender as? IndexPath else {
			return
		}
		
		guard let vc = segue.destination as? MemeDetailVC else {
			return
		}
		
		vc.memeImage = memes[(indexPath as NSIndexPath).row].memeImage
		
	}

}
